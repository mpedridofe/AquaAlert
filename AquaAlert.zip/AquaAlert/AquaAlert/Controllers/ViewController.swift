//
//  ViewController.swift
//  AquaAlert
//
//  Created by Marta on 22/10/24.
//

import UIKit

class ViewController: UIViewController {
    
    
    
    // conectar campos de texto
    @IBOutlet weak var nombreTextField: UITextField!
    @IBOutlet weak var edadTextField: UITextField!
    @IBOutlet weak var pesoTextField: UITextField!
    @IBOutlet weak var condicionesTextField: UITextField!
    
    @IBOutlet weak var hidratacionLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        hidratacionLabel.text = ""
    }
    
    // acción para guardar
    @IBAction func guardarDatos(_ sender: UIButton) {
        // validar y obtener los datos del usuario
        guard let nombre = nombreTextField.text,
              let edadString = edadTextField.text, let edad = Int(edadString),
              let pesoString = pesoTextField.text, let peso = Double(pesoString),
              let condicionesDeSalud = condicionesTextField.text else {
            print("Error al ingresar datos")
            return
        }
        
        // calcular hidratación en base al peso
        let nivelHidratacion = peso * 30.0
        
        // crear instancia del usuario
        let usuario = Usuario(nombre: nombre, edad: edad, peso: peso, condicionesDeSalud: condicionesDeSalud, nivelDeHidratacionObjetivo: nivelHidratacion)
        
        // muestra datos en consola
        print("Datos guardados:")
        usuario.mostrarDatos()
        
        hidratacionLabel.text = "Objetivo diario: \(String(format: "%.2f", nivelHidratacion)) ml"
    }


}

