//
//  Usuario.swift
//  AquaAlert
//
//  Created by Marta on 22/10/24.
//

import Foundation

class Usuario {
    var nombre: String
    var edad: Int
    var peso: Double
    var condicionesDeSalud: String
    var nivelDeHidratacionObjetivo: Double // en litros
    
    init(nombre: String, edad: Int, peso: Double, condicionesDeSalud: String, nivelDeHidratacionObjetivo: Double) {
        self.nombre = nombre
        self.edad = edad
        self.peso = peso
        self.condicionesDeSalud = condicionesDeSalud
        self.nivelDeHidratacionObjetivo = nivelDeHidratacionObjetivo
    }
    
    func mostrarDatos() {
        print("Nombre: \(nombre)")
        print("Edad: \(edad)")
        print("Peso: \(peso) kg")
        print("Condiciones de salud: \(condicionesDeSalud)")
        print("Objetivo de hidratación: \(nivelDeHidratacionObjetivo) ml al día")
    }
}
